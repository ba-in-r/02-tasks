## Nombre ( s ) de Autor ( es )
## R version 4.5.0

## limpiar entorno
rm(list = ls())

## cargar librerias
require(pacman)
p_load(tidyverse, skimr, janitor, rio)

##==: Punto 1


##==: Punto 2


##==: Punto 3


##==: Punto 4


##==: Punto 5

